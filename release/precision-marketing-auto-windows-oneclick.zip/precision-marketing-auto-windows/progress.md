# Precision Marketing Auto - Progress

## 2026-03-11

### 今日完成
- 恢复并稳定了自动化主脚本，完成多次回退与修复，确保第1/2/3步主流程可执行。
- 修复第3步执行员工关键问题：
  - 小窗口/缩放导致的视口外点击问题。
  - 默认区域残留清理逻辑（含“全国”双击清空）。
  - 可见面板绑定与状态回读修复（避免读到隐藏面板）。
- 修复第2步 iframe 早执行问题：
  - 增加“关键控件就绪”等待，避免空壳 iframe 导致主消费营运区和券规则ID未命中。
- 调整第3步策略为“不区分渠道切换”，统一按当前页面字段填充，避免“渠道未命中”干扰。
- 更新测试数据 `data/plans.csv` 为未来时间，避免“发送时间不能选历史时间”拦截。
- 完成可视化UI增强（已在之前提交）：
  - 支持下载 Excel 模板与 UTF-8 BOM CSV 模板。
  - 支持上传 `.xlsx` 并自动转 `.csv`。
  - 脚本读取 CSV 改为 `utf-8-sig`，兼容 Windows Excel。
- 安装了 `chrome-devtools` 技能（来自 `ChromeDevTools/chrome-devtools-mcp`）用于后续调试。

### 已打稳定标记
- `stable-cb0fe65-known-good-20260306`
- `stable-e2e-pass-20260306-employee-fixed`

### 当前状态
- 代码已推送到 `main`，最新提交包含：
  - `12d393e`（第3步入口强校验）
  - `0b72824`（测试数据时间更新）

### 下一步计划
- 用最新 `data/plans.csv` 进行一轮完整回归（第1/2/3步 + 保存）。
- 重点验证第2步在不同网络波动下的 iframe 就绪稳定性。
- 若通过，新增一个“生产发布候选标签”（stable tag）供全国推广回退。
- 继续优化可视化UI：
  - 增加业务“通过/失败判定清单”提示。
  - 增加第2步失败的可视化诊断提示（就绪状态、缺失控件项）。

### 本轮新增（渠道多选）
- 脚本新增参数：`--step3-channels`（支持多选，逗号分隔）。
- CSV 新增可选列：`channels`（例如：`会员通-发客户消息,会员通-发客户朋友圈`）。
- 第3步改为按渠道判断：
  - 选中“会员通-发客户消息”才强制填写/校验“短信内容”。
  - 未选短信渠道时，短信内容自动跳过，不再记失败。
- 第3步等待时间放宽，降低“加载慢导致未进入第3步”的误判。
- 可视化 UI 新增“第3步渠道多选”复选项，并透传到脚本执行。
- 渠道字段映射规则已落地：
  - 选择“短信” => 仅填写“短信内容”。
  - 选择“会员通-发客户消息” => 填写“结束时间 / 执行员工 / 发送内容”。
  - 选择“会员通-发客户朋友圈” => 填写“结束时间 / 执行员工 / 发送内容 / 朋友圈图片”。
  - 多选时按并集执行；未选择时按页面自动识别兜底。

### 2026-03-16 补充
- 测试时间已统一更新为：
  - 计划时间：`2026-03-16 08:00` 到 `2026-03-27 08:00`
  - 发送时间：`2026-03-20 08:00`
- 已同步文件：
  - `precision-auto-playwright-batch.py` 默认测试数据
  - `data/plans.csv`
  - `data/ui-test/plans-moments-local2.csv`

### 本轮新增（朋友圈图片上传）
- 第3步新增朋友圈图片上传逻辑（渠道=会员通-发客户朋友圈）：
  - 新增 CSV 字段：`moments_add_images`（是/否）、`moments_image_paths`（多图路径，`|` 分隔）。
  - 当 `moments_add_images=是` 时，脚本会逐张上传图片（按路径顺序，最多9张）。
  - 上传前校验：仅 `jpg/png`，单张小于 10MB，文件必须存在。
  - 当 `moments_add_images=否` 时，自动跳过图片上传。
- UI 模板（CSV/XLSX 下载）同步增加上述字段，并添加业务提示文案。
- UI 直接上传朋友圈图片能力：
  - 上传页新增“朋友圈上传图片 + 图片文件选择”控件（无需手工改本地CSV路径）。
  - 勾选后会把图片保存到 `ui_uploads/<task_id>_images/`，并自动回写任务CSV：
    - `moments_add_images=是`
    - `moments_image_paths=本地保存路径（按上传顺序）`
  - 这样业务只需要在UI上传 CSV + 图片即可执行，不需要手工在企业页面点文件夹。

### 本轮新增（Windows 一键使用）
- 新增 Windows 一键启动脚本：`scripts/windows/windows_start_ui.bat`
  - 自动创建 `.venv`
  - 自动安装 `requirements.txt` + `requirements-ui.txt`
  - 自动执行 `playwright install chromium`
  - 自动打开 `http://127.0.0.1:8790`
- 新增桌面图标生成脚本：`scripts/windows/create_desktop_shortcut.ps1`
  - 一次执行后在桌面生成“精准营销自动化工具”快捷方式
- 新增 Windows 打包脚本：`scripts/windows/build_windows_exe.bat`
  - 在 Windows 上可打包 `dist/PrecisionMarketingUIStarter.exe`
- README 已新增 Windows 使用说明，便于发给非技术执行同事。
- 新增“单文件下载包”输出：
  - 脚本：`scripts/windows/build_windows_release_zip.py`
  - 产物：`release/precision-marketing-auto-windows-oneclick.zip`
  - 同事可直接下载 zip，解压后双击 `scripts/windows/windows_start_ui.bat`。

---

## 维护约定
- 每次会话结束前更新本文件：
  - 今天做了什么
  - 完成了哪些
  - 下一步做什么
- 关键可回退版本必须同步写入“已打稳定标记”。

---

## 2026-03-16 进展补充

### 今天处理了什么
- 修正第3步渠道规则为最终版：
  - `短信` -> 仅填 `短信内容`
  - `会员通-发客户消息` -> 填 `结束时间 / 执行员工 / 发送内容`
  - `会员通-发客户朋友圈` -> 填 `结束时间 / 执行员工 / 发送内容 / 朋友圈图片`
- 将测试数据时间改为：
  - 计划时间：`2026-03-16 08:00:00` 到 `2026-03-27 08:00:00`
  - 发送时间：`2026-03-20 08:00:00`
- 修正第1步业务校验识别：
  - 若下一步后仍停留在第1步，优先识别 `发送时间不能选历史时间` 等提示，不再误判为第2步/第3步问题。
- 修正第2步完成后的“下一步”点击逻辑：
  - 点击后若仍停留在第2步，会自动补点一次。
- 修正第3步加载判定：
  - 识别文本、placeholder、`contenteditable` 编辑器，避免“已到第3步但脚本误判未进入”。
- 修正第3步 `会员通-发客户消息` 场景下的字段定位兜底：
  - `结束时间` 优先按可见 placeholder 定位。
  - `发送内容` 优先按可见编辑器定位，不再强依赖外层 `.item` 文案。
  - `执行员工` 优先按可见 cascader 输入框定位，不再强依赖“执行员工”标签块。

### 当前已完成
- 代码修改已落地到：
  - `precision-auto-playwright-batch.py`
- 语法检查已通过：
  - `python3 -m py_compile precision-auto-playwright-batch.py`

### 下一步
- 继续验证 `会员通-发客户消息` 第3步是否能稳定填入：
  - `结束时间`
  - `执行员工`
  - `发送内容`
- 若仍失败，优先根据新日志继续精修第3步控件定位，而不是回退整套流程。

### 结果更新（本轮）
- `会员通-发客户消息` 全流程已回归成功。
- 关键修复：
  - 第3步就绪判定从“宽松（placeholder/contenteditable）”改为“强信号命中（至少2项）”。
  - 第3步执行员工选择去除 `scroll_into_view_if_needed` 依赖，改为点击 + JS 事件兜底，规避元素不稳定超时。
  - 第3步按 `channels` 先切渠道页签再填字段，避免停留在默认渠道导致字段不可见。
  - 第3步（会员通-发客户消息）新增“添加小程序”自动化：
    - 点击“添加小程序”拉起弹窗
    - 配置小程序选择（默认：大参林健康）
    - 填写小程序标题、页面路径
    - 上传小程序封面（本地文件）
    - 点击弹窗确认

## 2026-03-17 进展补充

### 今天处理了什么
- 完成业务端 UI 调整：
  - 去掉“操作人”输入项。
  - 新增本地缓存（任务列表、日志、渠道勾选、高级配置参数）。
  - 优化第1/2/3步布局和对齐（高级配置按钮同排、渠道默认不勾选会员通消息、字段对齐）。
  - 第3步“小程序链接”文案与提示统一。
- 模板体验优化：
  - 下载 CSV/XLSX 模板改为中文表头，便于业务直接填写。
  - 上传时自动把中文表头映射回脚本英文字段，兼容旧逻辑。
- Windows 安装与升级链路落地：
  - 重写 `scripts/windows/windows_start_ui.bat`（稳定检查 Python、自动建 venv、依赖安装打标记、启动 UI）。
  - 新增 `scripts/windows/windows_install_or_update.ps1`（从 GitHub Release 拉取最新 zip 并安装/覆盖更新）。
  - 新增 `scripts/windows/install_or_update_from_github.bat`（业务双击安装/更新入口）。
  - 新增 `scripts/windows/windows_update.bat`（已安装目录内一键更新）。
  - 更新 `scripts/windows/build_windows_release_zip.py`，将新脚本打入发布包并更新快速说明。
  - 更新 `README.md` 的 Windows 使用说明，改为“安装/启动/更新”标准路径。

### 当前已完成
- 新发布包已可生成：`release/precision-marketing-auto-windows-oneclick.zip`
- 发布包已包含：
  - `scripts/windows/windows_start_ui.bat`
  - `scripts/windows/windows_update.bat`
  - `scripts/windows/install_or_update_from_github.bat`
  - `scripts/windows/windows_install_or_update.ps1`
- Python 语法检查通过：
  - `ui_app/server.py`
  - `scripts/windows/build_windows_release_zip.py`
  - `precision-auto-playwright-batch.py`

### 下一步
- 在 1 台 Windows 业务机走一遍真实安装流程（仅双击安装脚本），确认首次启动耗时与失败率。
- 将 Release 页面固定为“最新稳定包下载入口”（便于全国同事统一获取）。
- 增加“启动前环境自检页面提示”（Chrome/CDP/端口占用）以降低支持成本。

## 2026-03-17 进展补充（第2步与模板）

### 今天处理了什么
- 第2步目标分群增强：
  - 支持主消费营运区路径写法（例如：`华中大区-江西省区-九江`），自动按路径展开并定位到末级节点勾选。
  - 若页面未出现“选择数据”控件，则主消费营运区自动跳过，不阻断流程。
- 第2步“券规则ID”增强：
  - 若页面未出现券规则ID行，自动跳过，不阻断流程。
- 第2步“其他字段缺失自动跳过”增强：
  - 更新方式字段缺失时自动跳过。
  - 预跑按钮缺失时自动跳过。
  - 严格模式下校验项改为按“配置了且页面存在/可操作”动态校验，不再固定强拦。
- UI 模板下载字段精简（业务版）：
  - 模板已去掉以下列：`分群名称`、`第3步渠道(可多选)`、`朋友圈是否上传图片`、`朋友圈图片路径(用|分隔)`、`会员通消息是否添加小程序`、`小程序名称`、`小程序标题`、`小程序封面路径`、`小程序链接`。
  - 上传仍兼容这些字段（若文件里有，系统可识别），只是模板不再默认暴露。
- 新增测试文件：
  - `data/ui-test/plans-step2-area-path.csv`（用于验证“华中大区-江西省区-九江”路径选择）。

### 当前已完成
- 代码已提交并推送：`e202fdb`
- 语法检查通过：
  - `precision-auto-playwright-batch.py`
  - `ui_app/server.py`

### 下一步
- 用 UI 页面导入 `plans-step2-area-path.csv` 实测第2步路径勾选。
- 若线上页面结构再变，继续补充“节点文本命中 + 可见性 + 兜底点击”策略。

## 2026-03-18 进展补充（创建链接策略 + 业务网页入口）

### 今天处理了什么
- 创建链接策略升级：
  - 新增组合渠道规则：当第3步同时选择 `短信` + `会员通-发客户消息` 时，自动使用：
    - `https://precision.dslyy.com/admin#/marketingTemplate/use?useId=600035736992907264`
- 新增“手动创建链接”能力（优先级最高）：
  - 支持 CLI 参数：`--create-url`
  - 支持 CSV 字段：`create_url`
  - 优先级：手动创建链接 > CSV create_url > 组合渠道规则 > 单渠道规则 > 默认链接。
- 业务网页版（第1步）新增“创建链接”输入框：
  - 可手动填写创建链接，上传任务时透传到脚本执行。
  - 增加动态提示文案：根据勾选渠道显示当前自动匹配的 useId（含组合渠道提示）。
  - 本地缓存已纳入 `create_url` 字段，刷新后保留。

### 当前已完成
- 代码改动已完成并通过语法检查：
  - `precision-auto-playwright-batch.py`
  - `ui_app/server.py`

### 下一步
- 用业务网页版实测以下场景：
  1) 只选短信 -> 自动匹配短信链接。
  2) 只选会员通-发客户消息 -> 自动匹配会员通消息链接。
  3) 同时选短信+会员通-发客户消息 -> 自动匹配组合链接 `600035736992907264`。
  4) 手动填写创建链接 -> 应覆盖自动匹配结果。
